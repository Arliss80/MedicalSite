import express from 'express';
import cors from 'cors';
import fileUpload from 'express-fileupload';
import Database from 'better-sqlite3';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const db = new Database(join(__dirname, 'applications.db'));

const app = express();

app.use(cors());
app.use(express.json());
app.use(fileUpload({
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB max file size
  createParentPath: true
}));

// Initialize database
db.exec(`
  CREATE TABLE IF NOT EXISTS applications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    position TEXT NOT NULL,
    resume_path TEXT NOT NULL,
    cover_letter TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )
`);

// Handle application submission
app.post('/api/applications', (req, res) => {
  try {
    const { name, email, position, coverLetter } = req.body;
    
    if (!req.files || !req.files.resume) {
      return res.status(400).json({ error: 'Resume file is required' });
    }

    const resume = req.files.resume;
    const resumePath = join(__dirname, 'uploads', `${Date.now()}-${resume.name}`);
    
    // Save the file
    resume.mv(resumePath, (err) => {
      if (err) {
        return res.status(500).json({ error: 'Error uploading file' });
      }

      // Save to database
      const stmt = db.prepare(
        'INSERT INTO applications (name, email, position, resume_path, cover_letter) VALUES (?, ?, ?, ?, ?)'
      );
      
      stmt.run(name, email, position, resumePath, coverLetter);
      
      res.json({ message: 'Application submitted successfully' });
    });
  } catch (error) {
    console.error('Error submitting application:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});