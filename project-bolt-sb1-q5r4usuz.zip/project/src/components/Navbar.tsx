import React, { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import { Logo } from './Logo';

export function Navbar() {
  const [isGLP1Open, setIsGLP1Open] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const timeoutRef = useRef<number | null>(null);

  const handleMouseEnter = () => {
    if (timeoutRef.current) {
      window.clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    setIsGLP1Open(true);
  };

  const handleMouseLeave = () => {
    timeoutRef.current = window.setTimeout(() => {
      setIsGLP1Open(false);
    }, 300); // 300ms delay before closing
  };

  useEffect(() => {
    return () => {
      if (timeoutRef.current) {
        window.clearTimeout(timeoutRef.current);
      }
    };
  }, []);

  return (
    <nav className="bg-medallus-blue px-6 py-4 fixed w-full z-50">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <Link to="/">
          <Logo />
        </Link>
        
        {/* Desktop Navigation */}
        <div className="hidden md:flex space-x-8">
          <Link to="/" className="text-white hover:text-medallus-secondary transition font-opensans">Home</Link>
          <Link to="/about" className="text-white hover:text-medallus-secondary transition font-opensans">About</Link>
          <Link to="/benefits" className="text-white hover:text-medallus-secondary transition font-opensans">Benefits</Link>
          <Link to="/services" className="text-white hover:text-medallus-secondary transition font-opensans">Services</Link>
          <Link to="/proven-concept" className="text-white hover:text-medallus-secondary transition font-opensans">Proven Concept</Link>
          <div 
            ref={dropdownRef}
            className="relative group"
            onMouseEnter={handleMouseEnter}
            onMouseLeave={handleMouseLeave}
          >
            <Link to="/glp1" className="text-white hover:text-medallus-secondary transition font-opensans">GLP-1</Link>
            {isGLP1Open && (
              <div 
                className="absolute left-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-2"
                onMouseEnter={handleMouseEnter}
                onMouseLeave={handleMouseLeave}
              >
                <Link 
                  to="/glp1/disclosure" 
                  className="block px-4 py-2 text-medallus-text hover:bg-gray-100 transition font-opensans"
                >
                  Program Disclosures
                </Link>
              </div>
            )}
          </div>
          <Link to="/locations" className="text-white hover:text-medallus-secondary transition font-opensans">Locations</Link>
          <Link to="/contact" className="text-white hover:text-medallus-secondary transition font-opensans">Contact</Link>
        </div>

        {/* Mobile Menu Button */}
        <button
          className="md:hidden text-white"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? (
            <X className="h-6 w-6" />
          ) : (
            <Menu className="h-6 w-6" />
          )}
        </button>
      </div>

      {/* Mobile Navigation */}
      {isMobileMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-medallus-blue border-t border-white/10">
          <div className="px-6 py-4 space-y-4">
            <Link 
              to="/" 
              className="block text-white hover:text-medallus-secondary transition font-opensans"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Home
            </Link>
            <Link 
              to="/about" 
              className="block text-white hover:text-medallus-secondary transition font-opensans"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              About
            </Link>
            <Link 
              to="/benefits" 
              className="block text-white hover:text-medallus-secondary transition font-opensans"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Benefits
            </Link>
            <Link 
              to="/services" 
              className="block text-white hover:text-medallus-secondary transition font-opensans"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Services
            </Link>
            <Link 
              to="/proven-concept" 
              className="block text-white hover:text-medallus-secondary transition font-opensans"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Proven Concept
            </Link>
            <div>
              <Link 
                to="/glp1" 
                className="block text-white hover:text-medallus-secondary transition font-opensans"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                GLP-1
              </Link>
              <Link 
                to="/glp1/disclosure" 
                className="block text-white/80 hover:text-medallus-secondary transition font-opensans pl-4 mt-2 text-sm"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Program Disclosures
              </Link>
            </div>
            <Link 
              to="/locations" 
              className="block text-white hover:text-medallus-secondary transition font-opensans"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Locations
            </Link>
            <Link 
              to="/contact" 
              className="block text-white hover:text-medallus-secondary transition font-opensans"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Contact
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
}