import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Phone } from 'lucide-react';
import { Logo } from './Logo';

export function Footer() {
  return (
    <footer className="bg-medallus-text text-white py-12">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <Logo />
            <p className="mt-4 text-gray-400 font-opensans">
              Bringing quality healthcare closer to your workplace.
            </p>
          </div>
          <div>
            <h3 className="font-lato font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2 font-opensans">
              <li><Link to="/about" className="text-gray-400 hover:text-white transition">About</Link></li>
              <li><Link to="/benefits" className="text-gray-400 hover:text-white transition">Benefits</Link></li>
              <li><Link to="/services" className="text-gray-400 hover:text-white transition">Services</Link></li>
              <li><Link to="/locations" className="text-gray-400 hover:text-white transition">Locations</Link></li>
              <li><Link to="/contact" className="text-gray-400 hover:text-white transition">Contact</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="font-lato font-bold mb-4">Contact</h3>
            <ul className="space-y-2 text-gray-400 font-opensans">
              <li className="flex items-center space-x-2">
                <MapPin className="h-4 w-4" />
                <span>10433 S Redwood Rd, South Jordan, UT 84095</span>
              </li>
              <li className="flex items-center space-x-2">
                <Phone className="h-4 w-4" />
                <span>(801) 810-7058</span>
              </li>
              <li>Email: ArlissF@medallus.com</li>
            </ul>
          </div>
          <div>
            <h3 className="font-lato font-bold mb-4">Business Hours</h3>
            <ul className="space-y-2 text-gray-400 font-opensans">
              <li>Monday - Friday: 9am - 5pm</li>
              <li>Saturday - Sunday: Closed</li>
            </ul>
          </div>
        </div>
        <div className="mt-12 pt-8 border-t border-gray-800 text-center text-gray-400 font-opensans">
          <p>&copy; {new Date().getFullYear()} Medallus Healthcare. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}