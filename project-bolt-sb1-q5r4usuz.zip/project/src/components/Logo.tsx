import React from 'react';

interface LogoProps {
  className?: string;
}

export function Logo({ className = '' }: LogoProps) {
  return (
    <div className={`flex items-center ${className}`}>
      <img 
        src="https://static.wixstatic.com/media/39a8a6_e8196d3bfd4544e699b50c50e792ea36~mv2.png" 
        alt="Medallus Medical" 
        className="h-20 w-auto"
      />
    </div>
  );
}