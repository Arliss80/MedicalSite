import React from 'react';
import { AlertCircle, CheckCircle2, FileText, Scale } from 'lucide-react';

export function GLP1DisclosurePage() {
  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="relative py-16 bg-medallus-blue overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white/10 via-transparent to-transparent" />
        </div>
        <div className="max-w-4xl mx-auto px-6 relative">
          <div className="text-center">
            <h1 className="text-4xl font-lato font-bold text-white leading-tight">
              Medallus GLP-1 Program Compliance & Safety Protocols
            </h1>
            <p className="mt-4 text-xl text-white/80">
              Committed to Regulatory Compliance. Focused on Patient Care.
            </p>
          </div>
        </div>
      </section>

      {/* FDA Update Section */}
      <section className="py-12 bg-white">
        <div className="max-w-4xl mx-auto px-6">
          <div className="bg-blue-50 border-l-4 border-blue-500 p-6 rounded-r-lg mb-12">
            <div className="flex items-start">
              <AlertCircle className="h-6 w-6 text-blue-500 mr-4 mt-1 flex-shrink-0" />
              <div>
                <h2 className="text-xl font-lato font-bold text-blue-800 mb-2">March 2025 Update: FDA Compounding Guidelines</h2>
                <p className="text-blue-700">
                  The FDA has officially ended the drug shortage designation for GLP-1 medications:
                </p>
                <ul className="mt-2 space-y-1 text-blue-700">
                  <li>• Tirzepatide: Compounding grace period ended March 19, 2025</li>
                  <li>• Semaglutide: Ends May 22, 2025</li>
                </ul>
              </div>
            </div>
          </div>

          <p className="text-lg text-medallus-text mb-8">
            Medallus has adapted all internal protocols to align with current FDA guidelines while continuing to safely prescribe compounded GLP-1 therapies through our licensed national compounding pharmacy network.
          </p>
        </div>
      </section>

      {/* When Is Compounding Allowed Section */}
      <section className="py-12 bg-gray-50">
        <div className="max-w-4xl mx-auto px-6">
          <h2 className="text-2xl font-lato font-bold text-medallus-blue mb-6">
            When Is Compounding Still Allowed?
          </h2>
          <p className="text-lg text-medallus-text mb-6">
            Under Section 503A of the Federal Food, Drug, and Cosmetic Act, compounding is permitted only if specific criteria are met:
          </p>
          <div className="space-y-4">
            {[
              'The medication is customized for an individual patient',
              'The formulation includes clinical additives (e.g., B3, B6, B12)',
              'The dose varies by ±10% or more from commercial versions',
              'The provider documents a significant clinical difference'
            ].map((item, index) => (
              <div key={index} className="flex items-start space-x-3">
                <CheckCircle2 className="h-6 w-6 text-medallus-red flex-shrink-0 mt-1" />
                <p className="text-medallus-text">{item}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Protocols Section */}
      <section className="py-12 bg-white">
        <div className="max-w-4xl mx-auto px-6">
          <h2 className="text-2xl font-lato font-bold text-medallus-blue mb-6">
            What Protocols Are Medallus Following?
          </h2>
          <div className="bg-gray-50 rounded-xl p-8">
            <h3 className="text-xl font-lato font-bold text-medallus-blue mb-4">
              All GLP-1 prescriptions and formulations through Medallus are:
            </h3>
            <div className="space-y-6">
              <div>
                <h4 className="font-lato font-bold text-medallus-blue mb-2">Prescribed by a licensed provider with:</h4>
                <ul className="list-disc list-inside space-y-2 text-medallus-text ml-4">
                  <li>Individualized dosing for each patient</li>
                  <li>Additives to address fatigue, nausea, or GI symptoms</li>
                  <li>Medical justification documented in patient charts</li>
                  <li>Proper ICD-10 coding for diagnosis and clinical tracking</li>
                </ul>
              </div>
              <div>
                <h4 className="font-lato font-bold text-medallus-blue mb-2">Dispensed by licensed 503A compounding pharmacies in full compliance with:</h4>
                <ul className="list-disc list-inside space-y-2 text-medallus-text ml-4">
                  <li>Sterility and potency testing</li>
                  <li>Patient-specific prescriptions only</li>
                  <li>No bulk orders or in-office stockpiling</li>
                </ul>
              </div>
              <p className="text-medallus-text">
                Monitored with ongoing patient evaluations, clinical documentation, and remote follow-ups
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Clinical Difference Section */}
      <section className="py-12 bg-gray-50">
        <div className="max-w-4xl mx-auto px-6">
          <h2 className="text-2xl font-lato font-bold text-medallus-blue mb-6">
            What Is a "Significant Clinical Difference"?
          </h2>
          <div className="bg-white rounded-xl p-8 shadow-sm">
            <div className="flex items-start space-x-4 mb-6">
              <FileText className="h-8 w-8 text-medallus-red flex-shrink-0" />
              <div>
                <p className="text-medallus-text italic mb-4">
                  "A change is made for an identified individual patient, and the prescribing practitioner has determined that the change will produce a significant difference for that patient."
                </p>
                <p className="text-sm text-medallus-text">— FDA Guidance</p>
              </div>
            </div>
            <h3 className="font-lato font-bold text-medallus-blue mb-3">Examples include:</h3>
            <ul className="list-disc list-inside space-y-2 text-medallus-text ml-4">
              <li>Adding B12 to reduce nausea or support energy</li>
              <li>Altering dosing schedules for plateau prevention</li>
              <li>Tailoring treatments for patients with sensitivity to commercial formulas</li>
            </ul>
          </div>
        </div>
      </section>

      {/* Commitment Section */}
      <section className="py-12 bg-white">
        <div className="max-w-4xl mx-auto px-6">
          <h2 className="text-2xl font-lato font-bold text-medallus-blue mb-6">
            Medallus Is Committed to:
          </h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-gray-50 p-6 rounded-xl">
              <Scale className="h-8 w-8 text-medallus-red mb-4" />
              <p className="text-medallus-text">Full compliance with federal compounding regulations</p>
            </div>
            <div className="bg-gray-50 p-6 rounded-xl">
              <CheckCircle2 className="h-8 w-8 text-medallus-red mb-4" />
              <p className="text-medallus-text">Safe and effective GLP-1 prescribing and monitoring</p>
            </div>
            <div className="bg-gray-50 p-6 rounded-xl">
              <AlertCircle className="h-8 w-8 text-medallus-red mb-4" />
              <p className="text-medallus-text">Transparent communication with employers and patients</p>
            </div>
          </div>
          <p className="mt-8 text-center text-medallus-text">
            We appreciate your trust in Medallus as we continue delivering evidence-based, patient-first solutions for weight management and metabolic health.
          </p>
        </div>
      </section>
    </div>
  );
}