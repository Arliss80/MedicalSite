import React from 'react';
import { Link } from 'react-router-dom';
import { Users, DollarSign, Heart, Building2, Stethoscope, Clock, FlaskRound as Flask, TrendingDown, CheckCircle2, BarChart } from 'lucide-react';

export function HomePage() {
  return (
    <div className="min-h-screen">
      {/* Hero Section with Parallax Effect */}
      <header className="relative h-screen overflow-hidden">
        <div className="absolute inset-0 transform scale-105 origin-center transition-transform duration-1000">
          <img
            src="https://static.wixstatic.com/media/39a8a6_65a680ac85c64fa6b2e001c710435cc6~mv2.png"
            alt="Team of medical providers"
            className="w-full h-full object-cover object-top"
          />
          <div className="absolute inset-0 bg-gradient-to-br from-medallus-blue/95 via-medallus-blue/80 to-transparent" />
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-6 h-full flex items-center pt-20">
          <div className="max-w-3xl">
            <span className="inline-block px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full text-white font-lato text-sm mb-6">
              Revolutionizing Workplace Healthcare
            </span>
            <h1 className="text-5xl md:text-7xl font-lato font-bold text-white leading-tight">
              Bringing Healthcare Closer to Your Workplace
            </h1>
            <p className="mt-8 text-xl text-white/90 font-opensans leading-relaxed">
              Medallus 8 near-site clinics reduces your company's healthcare costs with high-quality, convenient healthcare for employees right where they need it most - near their homes and workplace.
            </p>
            <div className="mt-12 flex flex-col sm:flex-row gap-6">
              <Link to="/contact" className="group px-8 py-4 bg-medallus-red text-white rounded-full font-lato font-bold hover:bg-opacity-90 transition-all duration-300 transform hover:translate-y-[-2px] hover:shadow-lg text-center flex items-center justify-center">
                Schedule a Consultation
                <svg className="w-5 h-5 ml-2 transform transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
              </Link>
              <Link to="/about" className="px-8 py-4 border-2 border-white text-white rounded-full font-lato font-bold hover:bg-white hover:text-medallus-blue transition-all duration-300 text-center">
                Learn More
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* About Section with Asymmetric Design */}
      <section className="py-32 bg-white relative overflow-hidden">
        <div className="absolute right-0 top-0 w-1/3 h-full bg-medallus-blue/5 transform skew-x-12" />
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <span className="text-medallus-red font-lato font-bold uppercase tracking-wider">Who We Are</span>
              <h2 className="mt-4 text-4xl font-lato font-bold text-medallus-blue leading-tight">
                Redefining Workplace Healthcare
              </h2>
              <p className="mt-6 text-lg text-medallus-text leading-relaxed">
                You don't need to be a large company to provide your employees with access to a dedicated clinic. Medallus Near Site Clinics serve as your company's clinics across multiple Salt Lake locations—no matter the size of your business.
              </p>
              <Link to="/about" className="mt-8 inline-flex items-center text-medallus-blue font-lato font-bold group">
                Learn More About Us
                <span className="ml-2 transform transition-transform group-hover:translate-x-2">→</span>
              </Link>
            </div>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&q=80"
                alt="Modern medical consultation"
                className="rounded-2xl shadow-2xl"
              />
              <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-xl shadow-lg">
                <div className="flex items-center space-x-4">
                  <Users className="h-10 w-10 text-medallus-red" />
                  <div>
                    <h4 className="font-lato font-bold text-medallus-blue">Patient-Centric</h4>
                    <p className="text-sm text-medallus-text">Focused on your employees' needs</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section with Floating Cards */}
      <section className="py-32 bg-gradient-to-br from-gray-50 to-white relative">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center max-w-3xl mx-auto mb-20">
            <span className="text-medallus-red font-lato font-bold uppercase tracking-wider">Why Choose Us</span>
            <h2 className="mt-4 text-4xl font-lato font-bold text-medallus-blue">
              Benefits That Matter
            </h2>
            <p className="mt-6 text-lg text-medallus-text">
              Transform your employee healthcare experience with our innovative near-site clinic solutions. We combine convenience, quality care, and cost-effectiveness to create a healthcare model that benefits both employers and employees, leading to improved health outcomes and increased workplace productivity.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8 relative">
            <div className="bg-white p-8 rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2">
              <div className="bg-medallus-red/10 w-16 h-16 rounded-xl flex items-center justify-center mb-6">
                <Users className="h-8 w-8 text-medallus-red" />
              </div>
              <h3 className="text-xl font-lato font-bold text-medallus-blue">Employee Health</h3>
              <p className="mt-4 text-medallus-text leading-relaxed">
                Boost productivity with convenient access to quality healthcare, reducing absenteeism and promoting wellness.
              </p>
            </div>
            <div className="bg-white p-8 rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 md:translate-y-8">
              <div className="bg-medallus-red/10 w-16 h-16 rounded-xl flex items-center justify-center mb-6">
                <DollarSign className="h-8 w-8 text-medallus-red" />
              </div>
              <h3 className="text-xl font-lato font-bold text-medallus-blue">Cost Savings</h3>
              <p className="mt-4 text-medallus-text leading-relaxed">
                Significantly reduce healthcare costs through preventive care and efficient management of health resources.
              </p>
            </div>
            <div className="bg-white p-8 rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2">
              <div className="bg-medallus-red/10 w-16 h-16 rounded-xl flex items-center justify-center mb-6">
                <Heart className="h-8 w-8 text-medallus-red" />
              </div>
              <h3 className="text-xl font-lato font-bold text-medallus-blue">Satisfaction</h3>
              <p className="mt-4 text-medallus-text leading-relaxed">
                Enhance employee satisfaction with premium healthcare benefits that show you care about their wellbeing.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* North Dakota Success Story */}
      <section className="py-24 bg-medallus-blue relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white/10 via-transparent to-transparent" />
        <div className="max-w-7xl mx-auto px-6 relative">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <span className="text-medallus-red font-lato font-bold uppercase tracking-wider">Success Story</span>
              <h2 className="mt-4 text-4xl font-lato font-bold text-white leading-tight">
                A Proven Model with Real Results
              </h2>
              <div className="mt-8 space-y-6">
                <p className="text-white/80 text-lg">
                  Medallus Nearsite Clinics have been operating successfully across three locations in North Dakota, serving school districts in the Jamestown area and beyond. Over the past four years, our clinics have consistently helped reduce healthcare spending for our clients—proving that our model works.
                </p>
                <div className="grid grid-cols-2 gap-6">
                  <div className="bg-white/10 backdrop-blur-sm p-6 rounded-xl border border-white/20">
                    <TrendingDown className="h-8 w-8 text-medallus-red mb-3" />
                    <h3 className="text-white font-lato font-bold">Reduced ER Visits</h3>
                    <p className="text-white/70 text-sm mt-2">Minimized unnecessary emergency room visits</p>
                  </div>
                  <div className="bg-white/10 backdrop-blur-sm p-6 rounded-xl border border-white/20">
                    <CheckCircle2 className="h-8 w-8 text-medallus-red mb-3" />
                    <h3 className="text-white font-lato font-bold">Better Management</h3>
                    <p className="text-white/70 text-sm mt-2">Improved chronic condition care</p>
                  </div>
                </div>
                <p className="text-white/80 text-lg">
                  By offering convenient, affordable access to care, we've minimized unnecessary ER visits, improved chronic condition management, and prioritized preventive care. The result? Healthier employees and significant cost savings for the districts we serve.
                </p>
              </div>
            </div>
            <div className="relative">
              <div className="bg-white p-8 rounded-2xl shadow-2xl">
                <BarChart className="h-16 w-16 text-medallus-red mb-6" />
                <h3 className="text-2xl font-lato font-bold text-medallus-blue mb-4">Proven Results</h3>
                <p className="text-medallus-text mb-8">
                  When it comes to controlling healthcare costs while improving outcomes, Medallus Nearsite Clinics offer a tested, reliable solution.
                </p>
                <Link 
                  to="/proven-concept"
                  className="inline-flex items-center text-medallus-blue font-lato font-bold group"
                >
                  See Our Proven Results
                  <span className="ml-2 transform transition-transform group-hover:translate-x-2">→</span>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section with Interactive Grid */}
      <section className="py-32 bg-[#6D6F70] relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white via-white/20 to-transparent" />
        </div>
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="flex flex-col md:flex-row gap-16 items-center">
            <div className="md:w-1/3">
              <span className="text-medallus-red font-lato font-bold uppercase tracking-wider">What We Offer</span>
              <h2 className="mt-4 text-4xl font-lato font-bold text-white leading-tight">
                Comprehensive Healthcare Services
              </h2>
              <p className="mt-6 text-lg text-white/80 leading-relaxed">
                From primary care to specialized services, we provide complete healthcare solutions tailored to your workforce.
              </p>
              <Link to="/services" className="mt-8 inline-block px-8 py-4 bg-white text-[#6D6F70] rounded-full font-lato font-bold hover:bg-opacity-90 transition-all duration-300 transform hover:-translate-y-1 hover:shadow-lg">
                Explore All Services
              </Link>
            </div>
            <div className="md:w-2/3 grid grid-cols-2 gap-6">
              <div className="bg-white/10 backdrop-blur p-6 rounded-2xl border border-white/20 hover:bg-white/20 transition-all duration-300">
                <Stethoscope className="h-10 w-10 text-medallus-red mb-4" />
                <h3 className="text-xl font-lato font-bold text-white">Primary Care</h3>
                <p className="mt-2 text-white/80">Comprehensive healthcare for your entire workforce</p>
              </div>
              <div className="bg-white/10 backdrop-blur p-6 rounded-2xl border border-white/20 hover:bg-white/20 transition-all duration-300 transform translate-y-8">
                <Heart className="h-10 w-10 text-medallus-red mb-4" />
                <h3 className="text-xl font-lato font-bold text-white">Urgent Care</h3>
                <p className="mt-2 text-white/80">Immediate care when your employees need it most</p>
              </div>
              <div className="bg-white/10 backdrop-blur p-6 rounded-2xl border border-white/20 hover:bg-white/20 transition-all duration-300">
                <Users className="h-10 w-10 text-medallus-red mb-4" />
                <h3 className="text-xl font-lato font-bold text-white">Wellness Programs</h3>
                <p className="mt-2 text-white/80">Preventive care and health education initiatives</p>
              </div>
              <div className="bg-white/10 backdrop-blur p-6 rounded-2xl border border-white/20 hover:bg-white/20 transition-all duration-300 transform translate-y-8">
                <Flask className="h-10 w-10 text-medallus-red mb-4" />
                <h3 className="text-xl font-lato font-bold text-white">Lab Services</h3>
                <p className="mt-2 text-white/80">On-site testing and quick results</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Locations Section with Map Integration */}
      <section className="py-32 bg-white relative">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <span className="text-medallus-red font-lato font-bold uppercase tracking-wider">Where to Find Us</span>
              <h2 className="mt-4 text-4xl font-lato font-bold text-medallus-blue leading-tight">
                Eight Convenient Locations
              </h2>
              <p className="mt-6 text-lg text-medallus-text leading-relaxed">
                With state-of-the-art clinics across Salt Lake, Davis, and Utah County areas, quality healthcare is always nearby.
              </p>
              <div className="mt-12 grid grid-cols-2 gap-8">
                <div className="flex items-start space-x-4">
                  <Clock className="h-8 w-8 text-medallus-red flex-shrink-0" />
                  <div>
                    <h3 className="font-lato font-bold text-medallus-blue">Extended Hours</h3>
                    <p className="mt-2 text-medallus-text">Open 7 days a week</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <Flask className="h-8 w-8 text-medallus-red flex-shrink-0" />
                  <div>
                    <h3 className="font-lato font-bold text-medallus-blue">Lab Services</h3>
                    <p className="mt-2 text-medallus-text">Quick in-house testing</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <Building2 className="h-8 w-8 text-medallus-red flex-shrink-0" />
                  <div>
                    <h3 className="font-lato font-bold text-medallus-blue">Full Equipment</h3>
                    <p className="mt-2 text-medallus-text">X-ray at every location</p>
                  </div>
                </div>
              </div>
              <Link to="/locations" className="mt-12 inline-block px-8 py-4 bg-medallus-blue text-white rounded-full font-lato font-bold hover:bg-opacity-90 transition-all duration-300">
                Find Your Nearest Clinic
              </Link>
            </div>
            <div className="relative">
              <img
                src="https://static.wixstatic.com/media/39a8a6_9d999b59be4e494998feae887af22fa0~mv2.png/v1/fill/w_1502,h_810,al_tr,q_90,enc_avif,quality_auto/39a8a6_9d999b59be4e494998feae887af22fa0~mv2.png"
                alt="Modern clinic location"
                className="rounded-2xl shadow-2xl"
              />
              <div className="absolute -bottom-8 -right-8 bg-medallus-blue p-8 rounded-2xl shadow-xl text-white">
                <p className="font-lato font-bold text-2xl">8 Locations</p>
                <p className="text-white/80">Across Utah</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact CTA with Dynamic Background */}
      <section className="py-32 bg-gradient-to-br from-medallus-blue via-medallus-blue to-medallus-secondary relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white/10 via-transparent to-transparent" />
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="text-center max-w-3xl mx-auto">
            <span className="inline-block px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full text-white font-lato text-sm mb-6">
              Get Started Today
            </span>
            <h2 className="text-4xl md:text-5xl font-lato font-bold text-white leading-tight">
              Ready to Transform Your Workplace Healthcare?
            </h2>
            <p className="mt-6 text-xl text-white/80 leading-relaxed">
              Contact us to learn how Medallus Near-Site Clinics can benefit your organization.
            </p>
            <Link to="/contact" className="mt-12 inline-block px-10 py-5 bg-white text-medallus-blue rounded-full font-lato font-bold hover:bg-opacity-90 transition-all duration-300 transform hover:-translate-y-1 hover:shadow-xl">
              Schedule a Consultation
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}