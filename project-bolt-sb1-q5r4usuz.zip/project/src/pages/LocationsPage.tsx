import React from 'react';
import { MapPin, Clock, Phone, Building2 } from 'lucide-react';

const locations = [
  {
    name: "West Valley",
    address: "3451 South 5600 West Suite F",
    city: "West Valley, UT 84120",
    hours: "Monday - Sunday: 9am - 8pm",
    image: "https://static.wixstatic.com/media/39a8a6_e00d7e2cd2674f82958df44c1f5580b7~mv2.jpg"
  },
  {
    name: "Draper",
    address: "1126 East 12300 South",
    city: "Draper, UT 84020",
    hours: "Monday - Sunday: 8am - 8pm",
    image: "https://static.wixstatic.com/media/39a8a6_1e57dfbd0ab94f3fa4ec6a52941524e2~mv2.jpg"
  },
  {
    name: "American Fork",
    address: "476 North 900 West Suite C",
    city: "American Fork, UT 84003",
    hours: "Monday - Sunday: 9am - 8pm",
    image: "https://static.wixstatic.com/media/39a8a6_0e8967b954664ff08c072f4de3c158ac~mv2.jpg"
  },
  {
    name: "Sandy",
    address: "7998 South 1300 East",
    city: "Sandy, UT 84094",
    hours: "Monday - Sunday: 9am - 7pm",
    image: "https://static.wixstatic.com/media/39a8a6_0b7c42b2b5c14bd9b6442b5baa20803b~mv2.jpg"
  },
  {
    name: "Holladay",
    address: "3934 South 2300 East Suite D",
    city: "Salt Lake City, UT 84124",
    hours: "Monday - Sunday: 9am - 7pm",
    image: "https://static.wixstatic.com/media/39a8a6_c14919b83c634012973e6ed2b7aae65c~mv2.jpg"
  },
  {
    name: "Layton",
    address: "1868 N 1200 W",
    city: "Layton, UT 84041",
    hours: "Monday - Sunday: 9am - 7pm",
    image: "https://static.wixstatic.com/media/39a8a6_def311278f2f409d91e39f887ff69eee~mv2.jpg"
  },
  {
    name: "South Jordan",
    address: "10433 South Redwood Road",
    city: "South Jordan, UT 84095",
    hours: "Monday - Sunday: 9am - 7pm",
    image: "https://static.wixstatic.com/media/39a8a6_738225e8425a4e9ebe281ba12af1b010~mv2.jpg"
  },
  {
    name: "South Bangerter",
    address: "13348 South Market Center Drive #100",
    city: "Riverton, UT 84065",
    hours: "Monday - Friday: 9am - 8pm\nSaturday - Sunday: Closed",
    image: "https://static.wixstatic.com/media/39a8a6_c5934b341a284820ab62c0d9c17be81c~mv2.jpg"
  }
];

export function LocationsPage() {
  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="relative py-32 bg-medallus-blue overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white/10 via-transparent to-transparent" />
        <div className="max-w-7xl mx-auto px-6 relative">
          <div className="max-w-3xl">
            <h1 className="text-5xl font-lato font-bold text-white leading-tight">
              Our Locations
            </h1>
            <p className="mt-6 text-xl text-white/80">
              With eight state-of-the-art facilities across Utah, quality healthcare is always within reach.
            </p>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="flex items-start space-x-4">
              <div className="bg-medallus-red/10 p-4 rounded-xl">
                <Clock className="h-6 w-6 text-medallus-red" />
              </div>
              <div>
                <h3 className="text-xl font-lato font-bold text-medallus-blue">Extended Hours</h3>
                <p className="mt-2 text-medallus-text">Open seven days a week into the evening for your convenience</p>
              </div>
            </div>
            <div className="flex items-start space-x-4">
              <div className="bg-medallus-red/10 p-4 rounded-xl">
                <Building2 className="h-6 w-6 text-medallus-red" />
              </div>
              <div>
                <h3 className="text-xl font-lato font-bold text-medallus-blue">Full Service Facilities</h3>
                <p className="mt-2 text-medallus-text">In-house lab and X-ray at every location</p>
              </div>
            </div>
            <div className="flex items-start space-x-4">
              <div className="bg-medallus-red/10 p-4 rounded-xl">
                <Phone className="h-6 w-6 text-medallus-red" />
              </div>
              <div>
                <h3 className="text-xl font-lato font-bold text-medallus-blue">Easy Access</h3>
                <p className="mt-2 text-medallus-text">Walk-in patients welcome</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Locations List and Map */}
      <section className="py-24 bg-gradient-to-br from-gray-50 to-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex flex-col lg:flex-row gap-12">
            {/* Map */}
            <div className="lg:w-1/3">
              <div className="sticky top-24">
                <div className="max-w-[300px]">
                  <img
                    src="https://static.wixstatic.com/media/39a8a6_53c484f24d5d4fd782a6cd2a22686fd6~mv2.png/v1/fill/w_507,h_926,al_c,lg_1,q_90,enc_avif,quality_auto/location%20map.png"
                    alt="Medallus Locations Map"
                    className="w-full h-auto rounded-2xl shadow-lg"
                  />
                </div>
              </div>
            </div>

            {/* Locations List */}
            <div className="lg:w-2/3">
              <h2 className="text-3xl font-lato font-bold text-medallus-blue mb-8">Our Locations</h2>
              <div className="grid md:grid-cols-2 gap-6">
                {locations.map((location, index) => (
                  <div 
                    key={index}
                    className="relative h-64 overflow-hidden rounded-xl shadow-md hover:shadow-lg transition-all duration-300 group"
                  >
                    <div 
                      className="absolute inset-0 bg-cover bg-center transform transition-transform duration-700 group-hover:scale-110"
                      style={{ backgroundImage: `url(${location.image})` }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/60 to-black/30" />
                    <div className="relative h-full p-6 flex flex-col justify-end text-white">
                      <h3 className="text-xl font-lato font-bold mb-3">{location.name}</h3>
                      <div className="flex items-start space-x-3">
                        <MapPin className="h-5 w-5 flex-shrink-0 mt-1" />
                        <address className="not-italic">
                          {location.address}<br />
                          {location.city}
                        </address>
                      </div>
                      <div className="mt-4 flex items-start space-x-2">
                        <Clock className="h-4 w-4 mt-1" />
                        <div className="text-sm whitespace-pre-line">
                          {location.hours}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-medallus-blue relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white/10 via-transparent to-transparent" />
        <div className="max-w-3xl mx-auto px-6 text-center relative">
          <h2 className="text-3xl font-lato font-bold text-white mb-6">
            Ready to Experience Better Healthcare?
          </h2>
          <p className="text-xl text-white/80 mb-8">
            Contact us to learn more about our locations and services
          </p>
          <button className="px-8 py-4 bg-white text-medallus-blue rounded-full font-lato font-bold hover:bg-opacity-90 transition-all duration-300 transform hover:-translate-y-1">
            Schedule a Visit
          </button>
        </div>
      </section>
    </div>
  );
}