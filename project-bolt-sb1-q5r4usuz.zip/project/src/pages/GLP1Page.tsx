import React from 'react';
import { Check, Brain, BarChart as ChartBar, Users, Sparkles, Apple, Activity, MessageCircle, LineChart, BarChart, AlertCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

export function GLP1Page() {
  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="relative py-32 bg-medallus-blue overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white/10 via-transparent to-transparent" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_right,_var(--tw-gradient-stops))] from-medallus-red/20 via-transparent to-transparent" />
        </div>
        <div className="max-w-7xl mx-auto px-6 relative">
          <div className="max-w-3xl">
            <div className="bg-white/10 backdrop-blur-sm px-4 py-2 rounded-lg inline-flex items-center mb-6">
              <AlertCircle className="h-5 w-5 text-white mr-2" />
              <Link to="/glp1/disclosure" className="text-white hover:text-medallus-red transition">
                View Important GLP-1 Program Updates and Disclosures
              </Link>
            </div>
            <h1 className="text-5xl font-lato font-bold text-white leading-tight">
              Support a Healthier Workforce with GLP-1 Weight Management
            </h1>
            <p className="mt-6 text-xl text-white/80">
              The MedallusPrime Employer-Based GLP-1 Program helps your employees achieve their health goals while controlling healthcare costs.
            </p>
          </div>
        </div>
      </section>

      {/* Overview Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl font-lato font-bold text-medallus-blue mb-8">
                Boost Employee Health While Controlling Costs
              </h2>
              <p className="text-lg text-medallus-text mb-8">
                Rising rates of obesity, diabetes, and metabolic conditions are driving up your healthcare costs and reducing productivity. At Medallus, we partner with employers to offer affordable, clinically monitored GLP-1 weight loss programs that help employees get healthier—and stay healthier.
              </p>
              <p className="text-lg text-medallus-text">
                Now you can offer a high-impact benefit that attracts top talent, supports your team, and delivers measurable ROI.
              </p>
            </div>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b"
                alt="Healthcare consultation"
                className="rounded-2xl shadow-2xl"
              />
              <div className="absolute -bottom-8 -right-8 bg-white p-8 rounded-2xl shadow-lg">
                <ChartBar className="h-8 w-8 text-medallus-red mb-4" />
                <p className="font-lato font-bold text-medallus-blue">Proven Results</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Program Details */}
      <section className="py-24 bg-gradient-to-br from-gray-50 to-white relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-medallus-blue/5 via-transparent to-transparent" />
        <div className="max-w-7xl mx-auto px-6 relative">
          <h2 className="text-3xl font-lato font-bold text-medallus-blue mb-12 text-center">About the Program</h2>
          <p className="text-lg text-medallus-text text-center mb-12 max-w-3xl mx-auto">
            Medallus provides access to compounded Semaglutide and Tirzepatide — at up to 70% less than retail cost.
          </p>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
              <Activity className="h-12 w-12 text-medallus-red mb-6" />
              <h3 className="text-xl font-lato font-bold text-medallus-blue mb-4">Medical Evaluation</h3>
              <p className="text-medallus-text">Comprehensive medical evaluation and baseline labs to ensure safe and effective treatment</p>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
              <Sparkles className="h-12 w-12 text-medallus-red mb-6" />
              <h3 className="text-xl font-lato font-bold text-medallus-blue mb-4">Quality Medications</h3>
              <p className="text-medallus-text">FDA-compliant compounded medications through licensed U.S. pharmacies</p>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
              <MessageCircle className="h-12 w-12 text-medallus-red mb-6" />
              <h3 className="text-xl font-lato font-bold text-medallus-blue mb-4">Ongoing Support</h3>
              <p className="text-medallus-text">Monthly clinical check-ins and dose management for optimal results</p>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
              <Apple className="h-12 w-12 text-medallus-red mb-6" />
              <h3 className="text-xl font-lato font-bold text-medallus-blue mb-4">Nutrition Guidance</h3>
              <p className="text-medallus-text">Dietitian-guided nutrition and lifestyle support throughout your journey</p>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
              <LineChart className="h-12 w-12 text-medallus-red mb-6" />
              <h3 className="text-xl font-lato font-bold text-medallus-blue mb-4">Progress Tracking</h3>
              <p className="text-medallus-text">Secure mobile app for tracking, education, and follow-ups</p>
            </div>
          </div>
        </div>
      </section>

      {/* Proven Outcomes */}
      <section className="py-24 bg-medallus-blue text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white/10 via-transparent to-transparent" />
        <div className="max-w-7xl mx-auto px-6 relative">
          <h2 className="text-3xl font-lato font-bold mb-12 text-center">Proven Outcomes</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white/10 backdrop-blur-sm p-6 rounded-xl border border-white/20">
              <div className="flex items-start space-x-3">
                <Check className="h-6 w-6 text-medallus-red flex-shrink-0" />
                <p className="text-lg">14.9% average weight loss in clinical studies with Semaglutide</p>
              </div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm p-6 rounded-xl border border-white/20">
              <div className="flex items-start space-x-3">
                <Check className="h-6 w-6 text-medallus-red flex-shrink-0" />
                <p className="text-lg">Greater than 25% total body weight loss possible with Tirzepatide</p>
              </div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm p-6 rounded-xl border border-white/20">
              <div className="flex items-start space-x-3">
                <Check className="h-6 w-6 text-medallus-red flex-shrink-0" />
                <p className="text-lg">Reduces risks for chronic conditions like diabetes, heart disease, and certain cancers</p>
              </div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm p-6 rounded-xl border border-white/20">
              <div className="flex items-start space-x-3">
                <Check className="h-6 w-6 text-medallus-red flex-shrink-0" />
                <p className="text-lg">Enhances energy, focus, and daily performance</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Medallus */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-3xl font-lato font-bold text-medallus-blue mb-12">Why Employers Choose Medallus</h2>
          <div className="grid lg:grid-cols-2 gap-16">
            <div className="space-y-8">
              <div className="flex items-start space-x-4">
                <div className="bg-medallus-red/10 p-3 rounded-xl">
                  <BarChart className="h-6 w-6 text-medallus-red" />
                </div>
                <div>
                  <h3 className="text-xl font-lato font-bold text-medallus-blue mb-3">Reduce Long-Term Claims Costs</h3>
                  <ul className="list-disc list-inside space-y-2 text-medallus-text">
                    <li>Lower chronic disease rates</li>
                    <li>Fewer high-cost claims</li>
                    <li>Decreased emergency room visits</li>
                    <li>Improved preventive care utilization</li>
                  </ul>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="bg-medallus-red/10 p-3 rounded-xl">
                  <Users className="h-6 w-6 text-medallus-red" />
                </div>
                <div>
                  <h3 className="text-xl font-lato font-bold text-medallus-blue mb-3">Improve Productivity</h3>
                  <ul className="list-disc list-inside space-y-2 text-medallus-text">
                    <li>Fewer sick days taken</li>
                    <li>Better on-the-job performance</li>
                    <li>Enhanced employee engagement</li>
                    <li>Reduced absenteeism</li>
                  </ul>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="bg-medallus-red/10 p-3 rounded-xl">
                  <Sparkles className="h-6 w-6 text-medallus-red" />
                </div>
                <div>
                  <h3 className="text-xl font-lato font-bold text-medallus-blue mb-3">Competitive Benefits Package</h3>
                  <ul className="list-disc list-inside space-y-2 text-medallus-text">
                    <li>Attract and retain top talent</li>
                    <li>Stand out in competitive industries</li>
                    <li>Demonstrate commitment to employee health</li>
                    <li>Increase employee satisfaction</li>
                  </ul>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="bg-medallus-red/10 p-3 rounded-xl">
                  <Brain className="h-6 w-6 text-medallus-red" />
                </div>
                <div>
                  <h3 className="text-xl font-lato font-bold text-medallus-blue mb-3">Data-Driven ROI Reporting</h3>
                  <ul className="list-disc list-inside space-y-2 text-medallus-text">
                    <li>Track program outcomes</li>
                    <li>Monitor utilization rates</li>
                    <li>Measure ROI impact</li>
                    <li>Comprehensive Springbuk reporting</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&q=80"
                alt="Business analytics and results"
                className="rounded-2xl shadow-2xl"
              />
              <div className="absolute -bottom-8 -right-8 bg-white p-8 rounded-2xl shadow-lg">
                <ChartBar className="h-8 w-8 text-medallus-red mb-4" />
                <p className="font-lato font-bold text-medallus-blue">Measurable Impact</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Education and Engagement */}
      <section className="py-24 bg-gradient-to-br from-gray-50 to-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-lato font-bold text-medallus-blue">Education + Engagement = Success</h2>
            <p className="mt-4 text-lg text-medallus-text">We support employees with comprehensive resources and tools</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <Activity className="h-10 w-10 text-medallus-red mb-4" />
              <h3 className="text-lg font-lato font-bold text-medallus-blue mb-2">On-site Screenings</h3>
              <p className="text-medallus-text">Evolt 360 body scan, lipid/glucose finger stick</p>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <MessageCircle className="h-10 w-10 text-medallus-red mb-4" />
              <h3 className="text-lg font-lato font-bold text-medallus-blue mb-2">Virtual Consultations</h3>
              <p className="text-medallus-text">Virtual dietitian consults for personalized guidance</p>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <LineChart className="h-10 w-10 text-medallus-red mb-4" />
              <h3 className="text-lg font-lato font-bold text-medallus-blue mb-2">App-based Monitoring</h3>
              <p className="text-medallus-text">Follow-ups and messaging through our secure platform</p>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <Brain className="h-10 w-10 text-medallus-red mb-4" />
              <h3 className="text-lg font-lato font-bold text-medallus-blue mb-2">Tailored Wellness</h3>
              <p className="text-medallus-text">Plans for gut health, hormones, lifestyle, and behavior</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-medallus-blue relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white/10 via-transparent to-transparent" />
        <div className="max-w-3xl mx-auto px-6 text-center relative">
          <h2 className="text-3xl font-lato font-bold text-white mb-6">
            Ready to Transform Your Workplace Health?
          </h2>
          <p className="text-xl text-white/80 mb-8">
            Contact us to learn more about implementing the GLP-1 program at your organization
          </p>
          <Link
            to="/contact"
            className="inline-block px-8 py-4 bg-white text-medallus-blue rounded-full font-lato font-bold hover:bg-opacity-90 transition-all duration-300 transform hover:-translate-y-1"
          >
            Schedule a Consultation
          </Link>
        </div>
      </section>
    </div>
  );
}