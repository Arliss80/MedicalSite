import React, { useState } from 'react';
import { MapPin, Mail, Clock, Briefcase as BriefCase, Phone } from 'lucide-react';

export function ContactPage() {
  // Contact form state
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
  });

  // Career form state
  const [careerFormData, setCareerFormData] = useState({
    name: '',
    email: '',
    position: '',
    coverLetter: '',
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.id]: e.target.value
    });
  };

  const handleCareerInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setCareerFormData({
      ...careerFormData,
      [e.target.id.replace('career-', '')]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Construct email body with form data
    const emailBody = `
Name: ${formData.name}
Email: ${formData.email}

Message:
${formData.message}
    `.trim();

    // Create mailto link with encoded subject and body
    const mailtoLink = `mailto:ArlissF@medallus.com?subject=Contact Form Submission from ${encodeURIComponent(formData.name)}&body=${encodeURIComponent(emailBody)}`;
    
    // Open default email client
    window.location.href = mailtoLink;
  };

  const handleCareerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Construct email body with career form data
    const emailBody = `
Name: ${careerFormData.name}
Email: ${careerFormData.email}
Position: ${careerFormData.position}

Cover Letter:
${careerFormData.coverLetter}

Note: Please reply to this email with your resume attached.
    `.trim();

    // Create mailto link with encoded subject and body
    const mailtoLink = `mailto:ArlissF@medallus.com?subject=Career Application for ${encodeURIComponent(careerFormData.position)} from ${encodeURIComponent(careerFormData.name)}&body=${encodeURIComponent(emailBody)}`;
    
    // Open default email client
    window.location.href = mailtoLink;
  };

  return (
    <div className="min-h-screen pt-20">
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h1 className="text-4xl font-lato font-bold text-medallus-blue mb-8">Contact Us</h1>
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <MapPin className="h-6 w-6 text-medallus-red flex-shrink-0" />
                  <div>
                    <h3 className="font-lato font-bold text-medallus-blue">Main Office</h3>
                    <p className="text-medallus-text">10433 S Redwood Rd, South Jordan, UT 84095</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <Phone className="h-6 w-6 text-medallus-red flex-shrink-0" />
                  <div>
                    <h3 className="font-lato font-bold text-medallus-blue">Phone</h3>
                    <p className="text-medallus-text">(801) 810-7058</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <Mail className="h-6 w-6 text-medallus-red flex-shrink-0" />
                  <div>
                    <h3 className="font-lato font-bold text-medallus-blue">Email</h3>
                    <p className="text-medallus-text">ArlissF@medallus.com</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <Clock className="h-6 w-6 text-medallus-red flex-shrink-0" />
                  <div>
                    <h3 className="font-lato font-bold text-medallus-blue">Business Hours</h3>
                    <p className="text-medallus-text">Monday - Friday: 9am - 5pm<br />Saturday - Sunday: Closed</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-50 p-8 rounded-xl">
              <h2 className="text-2xl font-lato font-bold text-medallus-blue mb-6">Send us a Message</h2>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-medallus-text mb-2">Name</label>
                  <input
                    type="text"
                    id="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-medallus-blue focus:border-transparent"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-medallus-text mb-2">Email</label>
                  <input
                    type="email"
                    id="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-medallus-blue focus:border-transparent"
                  />
                </div>
                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-medallus-text mb-2">Message</label>
                  <textarea
                    id="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    required
                    rows={4}
                    className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-medallus-blue focus:border-transparent"
                  ></textarea>
                </div>
                <button
                  type="submit"
                  className="w-full px-8 py-4 bg-medallus-red text-white rounded-full font-lato font-bold hover:bg-opacity-90 transition"
                >
                  Send Message
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Careers Section */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-lato font-bold text-medallus-blue mb-6">Join Our Team</h2>
              <p className="text-lg text-medallus-text mb-8">
                We're always looking for talented healthcare professionals to join our growing team. If you're passionate about providing exceptional patient care and want to be part of an innovative healthcare organization, we'd love to hear from you.
              </p>
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <div className="h-2 w-2 bg-medallus-red rounded-full" />
                  <p className="text-medallus-text">Competitive compensation and benefits</p>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="h-2 w-2 bg-medallus-red rounded-full" />
                  <p className="text-medallus-text">Professional development opportunities</p>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="h-2 w-2 bg-medallus-red rounded-full" />
                  <p className="text-medallus-text">Work-life balance with flexible scheduling</p>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="h-2 w-2 bg-medallus-red rounded-full" />
                  <p className="text-medallus-text">State-of-the-art facilities and equipment</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-lg">
              <h3 className="text-2xl font-lato font-bold text-medallus-blue mb-6">Submit Your Application</h3>
              <form onSubmit={handleCareerSubmit} className="space-y-6">
                <div>
                  <label htmlFor="career-name" className="block text-sm font-medium text-medallus-text mb-2">Full Name</label>
                  <input
                    type="text"
                    id="career-name"
                    value={careerFormData.name}
                    onChange={handleCareerInputChange}
                    required
                    className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-medallus-blue focus:border-transparent"
                  />
                </div>
                <div>
                  <label htmlFor="career-email" className="block text-sm font-medium text-medallus-text mb-2">Email</label>
                  <input
                    type="email"
                    id="career-email"
                    value={careerFormData.email}
                    onChange={handleCareerInputChange}
                    required
                    className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-medallus-blue focus:border-transparent"
                  />
                </div>
                <div>
                  <label htmlFor="position" className="block text-sm font-medium text-medallus-text mb-2">Position of Interest</label>
                  <select
                    id="position"
                    value={careerFormData.position}
                    onChange={handleCareerInputChange}
                    required
                    className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-medallus-blue focus:border-transparent"
                  >
                    <option value="">Select a position</option>
                    <option value="physician">Physician</option>
                    <option value="nurse">Nurse</option>
                    <option value="medical-assistant">Medical Assistant</option>
                    <option value="radiologic-technologist">Radiologic Technologist</option>
                    <option value="front-desk">Front Desk Staff</option>
                    <option value="other">Other</option>
                  </select>
                </div>
                <div>
                  <label htmlFor="career-coverLetter" className="block text-sm font-medium text-medallus-text mb-2">Cover Letter</label>
                  <textarea
                    id="career-coverLetter"
                    value={careerFormData.coverLetter}
                    onChange={handleCareerInputChange}
                    rows={4}
                    className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-medallus-blue focus:border-transparent"
                    placeholder="Tell us why you'd be a great fit for the team..."
                  ></textarea>
                </div>
                <div className="bg-blue-50 p-4 rounded-lg">
                  <p className="text-sm text-medallus-blue">
                    <strong>Note:</strong> After submitting this form, you'll be directed to your email client where you can attach your resume before sending.
                  </p>
                </div>
                <button
                  type="submit"
                  className="w-full px-8 py-4 bg-medallus-blue text-white rounded-full font-lato font-bold hover:bg-opacity-90 transition"
                >
                  Submit Application
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}