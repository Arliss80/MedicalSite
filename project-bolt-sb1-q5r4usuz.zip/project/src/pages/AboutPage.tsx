import React from 'react';
import { Award, Target, Users, Sparkles } from 'lucide-react';

export function AboutPage() {
  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="relative py-32 bg-gradient-to-br from-gray-50 to-white overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-medallus-blue/5 transform -skew-y-6" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-medallus-red/5 via-transparent to-transparent" />
        </div>
        <div className="max-w-7xl mx-auto px-6 relative">
          <div className="max-w-3xl">
            <h1 className="text-5xl font-lato font-bold text-medallus-blue leading-tight">
              Transforming Healthcare Delivery
            </h1>
            <p className="mt-6 text-xl text-medallus-text font-opensans">
              Medallus Near-Site Clinics bridge the gap between traditional healthcare and workplace wellness, offering accessible, high-quality medical services strategically located near your business.
            </p>
          </div>
        </div>
      </section>

      {/* Vision & Mission */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-16">
            <div className="relative">
              <img
                src="https://static.wixstatic.com/media/39a8a6_cdfa84318c7a47c8b99828b7618b53d0.jpg"
                alt="Modern medical facility"
                className="rounded-2xl shadow-2xl"
              />
              <div className="absolute -bottom-8 -right-8 bg-white p-8 rounded-2xl shadow-lg max-w-sm">
                <Award className="h-8 w-8 text-medallus-red mb-4" />
                <h3 className="text-xl font-lato font-bold text-medallus-blue">Excellence in Care</h3>
                <p className="mt-2 text-medallus-text">Committed to delivering exceptional healthcare services that exceed expectations.</p>
              </div>
            </div>
            <div className="flex flex-col justify-center">
              <div className="space-y-12">
                <div>
                  <h2 className="text-3xl font-lato font-bold text-medallus-blue mb-4">Our Vision</h2>
                  <p className="text-lg text-medallus-text">
                    To revolutionize workplace healthcare by creating a network of accessible, efficient, and cost-effective medical facilities that serve multiple employers in strategic locations.
                  </p>
                </div>
                <div>
                  <h2 className="text-3xl font-lato font-bold text-medallus-blue mb-4">Our Mission</h2>
                  <p className="text-lg text-medallus-text">
                    To provide convenient, high-quality healthcare that empowers employers and employees to take control of their health and well-being through innovative near-site clinic solutions.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Founder Section */}
      <section className="py-24 bg-gradient-to-br from-gray-50 to-white relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-medallus-blue/5 via-transparent to-transparent" />
        <div className="max-w-7xl mx-auto px-6 relative">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl font-lato font-bold text-medallus-blue mb-6">Our Founder</h2>
              <p className="text-lg text-medallus-text mb-6">
                Medallus was founded in 2000 by Dr. Rachot Vacharothone, who continues to actively own and operate all eight Utah clinic locations alongside his executive team and over 120 dedicated employees. Dr. Rachot's philosophy is simple: high-quality care begins with strong leadership and hands-on training. That's why he personally trains and mentors each provider, ensuring every team member delivers exceptional medical care with a focus on compassionate, patient-centered service.
              </p>
              <p className="text-lg text-medallus-text mb-6">
                Because Medallus operates independently—unaffiliated with hospital systems—we maintain full control over care decisions, helping to keep insurance claims low and healthcare costs affordable.
              </p>
              <p className="text-lg text-medallus-text">
                To further support your organization, our dedicated Medallus Outreach Team is assigned to actively engage your employees, ensuring their urgent care and primary care needs are met seamlessly across our eight conveniently located near-site clinics throughout Salt Lake.
              </p>
            </div>
            <div className="relative">
              <img
                src="https://static.wixstatic.com/media/39a8a6_d99fd31b2ebe45bd8e6167e3fd22e626.jpg"
                alt="Dr. Rachot Vacharothone"
                className="rounded-2xl shadow-2xl"
              />
              <div className="absolute -bottom-8 -right-8 bg-white p-8 rounded-2xl shadow-lg">
                <Users className="h-8 w-8 text-medallus-red mb-4" />
                <p className="font-lato font-bold text-medallus-blue">Leading Through Excellence</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-24 bg-medallus-blue relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white/10 via-transparent to-transparent" />
        <div className="max-w-7xl mx-auto px-6 relative">
          <h2 className="text-4xl font-lato font-bold text-white text-center mb-16">Our Core Values</h2>
          <div className="grid md:grid-cols-3 gap-12">
            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-to-b from-white/10 to-transparent rounded-3xl transform transition-transform group-hover:scale-105" />
              <div className="relative p-8">
                <Target className="h-12 w-12 text-medallus-red mb-6" />
                <h3 className="text-2xl font-lato font-bold text-white mb-4">Innovation</h3>
                <p className="text-white/80">
                  Continuously evolving our services and approaches to meet the changing needs of modern workplaces and their employees.
                </p>
              </div>
            </div>
            <div className="relative group md:translate-y-12">
              <div className="absolute inset-0 bg-gradient-to-b from-white/10 to-transparent rounded-3xl transform transition-transform group-hover:scale-105" />
              <div className="relative p-8">
                <Users className="h-12 w-12 text-medallus-red mb-6" />
                <h3 className="text-2xl font-lato font-bold text-white mb-4">Collaboration</h3>
                <p className="text-white/80">
                  Working closely with employers to create healthcare solutions that truly serve their workforce's needs.
                </p>
              </div>
            </div>
            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-to-b from-white/10 to-transparent rounded-3xl transform transition-transform group-hover:scale-105" />
              <div className="relative p-8">
                <Sparkles className="h-12 w-12 text-medallus-red mb-6" />
                <h3 className="text-2xl font-lato font-bold text-white mb-4">Excellence</h3>
                <p className="text-white/80">
                  Maintaining the highest standards in healthcare delivery, patient experience, and professional service.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl font-lato font-bold text-medallus-red mb-2">8</div>
              <div className="text-lg font-lato text-medallus-blue">Locations</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-lato font-bold text-medallus-red mb-2">Open 7</div>
              <div className="text-lg font-lato text-medallus-blue">Days a Week</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-lato font-bold text-medallus-red mb-2">25+</div>
              <div className="text-lg font-lato text-medallus-blue">Years Experience</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-lato font-bold text-medallus-red mb-2">98%</div>
              <div className="text-lg font-lato text-medallus-blue">Patient Satisfaction</div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}