import React from 'react';
import { Clock, DollarSign, Heart, Shield, Stethoscope, Users, Building2, BarChart as ChartBar, MapPin, FlaskRound as Flask } from 'lucide-react';

export function BenefitsPage() {
  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="relative py-32 bg-medallus-blue overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white/10 via-transparent to-transparent" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_right,_var(--tw-gradient-stops))] from-medallus-red/20 via-transparent to-transparent" />
        </div>
        <div className="max-w-7xl mx-auto px-6 relative">
          <div className="max-w-3xl">
            <h1 className="text-5xl font-lato font-bold text-white leading-tight">
              Transform Your Workplace Healthcare
            </h1>
            <p className="mt-6 text-xl text-white/80">
              Discover how our near-site clinics revolutionize employee healthcare delivery while reducing costs and improving outcomes.
            </p>
          </div>
        </div>
      </section>

      {/* Key Benefits Overview */}
      <section className="py-24 bg-white relative">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&q=80"
                alt="Modern medical consultation"
                className="rounded-2xl shadow-2xl"
              />
              <div className="absolute -bottom-8 -right-8 bg-white p-8 rounded-2xl shadow-lg">
                <ChartBar className="h-8 w-8 text-medallus-red mb-4" />
                <p className="font-lato font-bold text-medallus-blue">Proven ROI for Employers</p>
              </div>
            </div>
            <div>
              <h2 className="text-3xl font-lato font-bold text-medallus-blue mb-8">Why Choose Medallus Near-Site Clinics?</h2>
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="bg-medallus-red/10 p-3 rounded-xl">
                    <MapPin className="h-6 w-6 text-medallus-red" />
                  </div>
                  <div>
                    <h3 className="text-xl font-lato font-bold text-medallus-blue mb-2">Strategic Locations</h3>
                    <p className="text-medallus-text">Eight locations throughout Salt Lake near the workplace and where employees live</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-medallus-red/10 p-3 rounded-xl">
                    <Clock className="h-6 w-6 text-medallus-red" />
                  </div>
                  <div>
                    <h3 className="text-xl font-lato font-bold text-medallus-blue mb-2">Extended Hours</h3>
                    <p className="text-medallus-text">Open seven days a week into the weekend</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-medallus-red/10 p-3 rounded-xl">
                    <Users className="h-6 w-6 text-medallus-red" />
                  </div>
                  <div>
                    <h3 className="text-xl font-lato font-bold text-medallus-blue mb-2">Convenient Access</h3>
                    <p className="text-medallus-text">Convenient walk-in for both urgent care and primary care. No appointment necessary.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-medallus-red/10 p-3 rounded-xl">
                    <Flask className="h-6 w-6 text-medallus-red" />
                  </div>
                  <div>
                    <h3 className="text-xl font-lato font-bold text-medallus-blue mb-2">Full-Service Facilities</h3>
                    <p className="text-medallus-text">On-site lab and X-ray and large facility 4,000 to 6,000 sq ft.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-medallus-red/10 p-3 rounded-xl">
                    <DollarSign className="h-6 w-6 text-medallus-red" />
                  </div>
                  <div>
                    <h3 className="text-xl font-lato font-bold text-medallus-blue mb-2">Cost Savings</h3>
                    <p className="text-medallus-text">Lower healthcare costs through reduced ER visits and efficient resource management</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Detailed Benefits */}
      <section className="py-24 bg-gradient-to-br from-gray-50 to-white relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-medallus-blue/5 via-transparent to-transparent" />
        <div className="max-w-7xl mx-auto px-6 relative">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-lato font-bold text-medallus-blue">Comprehensive Benefits</h2>
            <p className="mt-4 text-lg text-medallus-text max-w-2xl mx-auto">
              Our near-site clinics offer a wide range of advantages that benefit both employers and employees
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-to-br from-white to-gray-50 rounded-2xl transform transition-all duration-300 group-hover:scale-[1.02]" />
              <div className="relative p-8 border border-gray-100 rounded-2xl">
                <h3 className="text-2xl font-lato font-bold text-medallus-blue mb-6 flex items-center">
                  <Building2 className="h-8 w-8 text-medallus-red mr-3" />
                  For Employers
                </h3>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <div className="h-2 w-2 bg-medallus-red rounded-full mt-2 flex-shrink-0" />
                    <p className="text-medallus-text">Reduced lost productivity from employee medical appointments</p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="h-2 w-2 bg-medallus-red rounded-full mt-2 flex-shrink-0" />
                    <p className="text-medallus-text">Lower emergency room utilization for non-emergency conditions</p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="h-2 w-2 bg-medallus-red rounded-full mt-2 flex-shrink-0" />
                    <p className="text-medallus-text">Decreased overall healthcare costs through preventive care</p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="h-2 w-2 bg-medallus-red rounded-full mt-2 flex-shrink-0" />
                    <p className="text-medallus-text">Enhanced employee retention through valuable benefits</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="relative group md:translate-y-12">
              <div className="absolute inset-0 bg-gradient-to-br from-white to-gray-50 rounded-2xl transform transition-all duration-300 group-hover:scale-[1.02]" />
              <div className="relative p-8 border border-gray-100 rounded-2xl">
                <h3 className="text-2xl font-lato font-bold text-medallus-blue mb-6 flex items-center">
                  <Users className="h-8 w-8 text-medallus-red mr-3" />
                  For Employees
                </h3>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <div className="h-2 w-2 bg-medallus-red rounded-full mt-2 flex-shrink-0" />
                    <p className="text-medallus-text">No out-of-pocket costs for clinic visits</p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="h-2 w-2 bg-medallus-red rounded-full mt-2 flex-shrink-0" />
                    <p className="text-medallus-text">Unlimited clinic visits for all your healthcare needs</p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="h-2 w-2 bg-medallus-red rounded-full mt-2 flex-shrink-0" />
                    <p className="text-medallus-text">Convenient access to quality healthcare near workplace</p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="h-2 w-2 bg-medallus-red rounded-full mt-2 flex-shrink-0" />
                    <p className="text-medallus-text">Reduced wait times and travel for medical care</p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="h-2 w-2 bg-medallus-red rounded-full mt-2 flex-shrink-0" />
                    <p className="text-medallus-text">Better management of chronic conditions</p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="h-2 w-2 bg-medallus-red rounded-full mt-2 flex-shrink-0" />
                    <p className="text-medallus-text">Improved access to preventive care services</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Highlight */}
      <section className="py-24 bg-medallus-blue text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white/10 via-transparent to-transparent" />
        <div className="max-w-7xl mx-auto px-6 relative">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl font-lato font-bold mb-8">Key Features</h2>
              <div className="space-y-8">
                <div className="flex items-start space-x-4">
                  <Shield className="h-8 w-8 text-medallus-red flex-shrink-0" />
                  <div>
                    <h3 className="text-xl font-lato font-bold mb-2">Comprehensive Care</h3>
                    <p className="text-white/80">Our near-site clinic model provide both primary care and urgent care services to prevent illness and to treat illnesses that often need visits to emergency room or hospitals</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <Stethoscope className="h-8 w-8 text-medallus-red flex-shrink-0" />
                  <div>
                    <h3 className="text-xl font-lato font-bold mb-2">Quality Healthcare</h3>
                    <p className="text-white/80">Our expert medical staff, paired with state-of-the-art facilities, allow us to treat a wide range of conditions in-house. As an independent provider, we avoid unnecessary referrals—helping to keep claims low and healthcare costs down</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <Heart className="h-8 w-8 text-medallus-red flex-shrink-0" />
                  <div>
                    <h3 className="text-xl font-lato font-bold mb-2">Wellness Focus</h3>
                    <p className="text-white/80">We offer on-site screenings with biometric scans to capture accurate health data, empowering your team to track progress and improve outcomes through objective measurementn</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1576671081837-49000212a370?auto=format&fit=crop&q=80"
                alt="Healthcare professional with patient"
                className="rounded-2xl shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}