import React from 'react';
import { Link } from 'react-router-dom';
import { BarChart, Target, Users, Sparkles, Activity, Heart, Clock, Building2, MapPin, DollarSign, Stethoscope, FileText } from 'lucide-react';

export function ProvenConceptPage() {
  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="relative py-32 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://static.wixstatic.com/media/39a8a6_3535db3643eb4754a8901d29cff4e21e~mv2.jpg"
            alt="Medical professionals"
            className="w-full h-full object-cover object-center"
          />
          <div className="absolute inset-0 bg-medallus-blue/80" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white/10 via-transparent to-transparent" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_right,_var(--tw-gradient-stops))] from-medallus-red/20 via-transparent to-transparent" />
        </div>
        <div className="max-w-7xl mx-auto px-6 relative">
          <div className="max-w-3xl">
            <h1 className="text-5xl font-lato font-bold text-white leading-tight">
              A Proven Healthcare Model That Delivers Real Results
            </h1>
            <p className="mt-6 text-xl text-white/80">
              See how Medallus Near-site Clinics helped public schools in North Dakota reduce healthcare costs and improve employee health outcomes over 5 years.
            </p>
          </div>
        </div>
      </section>

      {/* Key Achievements Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-lato font-bold text-medallus-blue">Trusted by Schools, Powered by Results</h2>
            <p className="mt-4 text-lg text-medallus-text">
              Medallus Near-site Clinics have been serving public school employees in North Dakota for over five years—delivering lower costs, healthier outcomes, and stronger engagement.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <div className="text-4xl font-lato font-bold text-medallus-red mb-2">1.6%</div>
              <p className="text-medallus-text">premium increase in 2025 (well below national average)</p>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <div className="text-4xl font-lato font-bold text-medallus-red mb-2">10%</div>
              <p className="text-medallus-text">forecasted stop-loss refund for 2024</p>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <div className="text-4xl font-lato font-bold text-medallus-red mb-2">57%</div>
              <p className="text-medallus-text">reduction in chronic care non-compliance</p>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <div className="text-4xl font-lato font-bold text-medallus-red mb-2">31%</div>
              <p className="text-medallus-text">reduction in preventive care non-compliance</p>
            </div>
          </div>
        </div>
      </section>

      {/* Data Visualization Section */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-lato font-bold text-medallus-blue mb-4">Real Results from North Dakota Schools</h2>
            <p className="text-lg text-medallus-text max-w-3xl mx-auto">
              Our 5-year analysis of North Dakota public schools demonstrates significant cost savings and improved healthcare outcomes.
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            <div>
              <div className="bg-white p-8 rounded-xl shadow-lg">
                <h3 className="text-2xl font-lato font-bold text-medallus-blue mb-6">Cost Reduction Highlights</h3>
                <div className="space-y-6">
                  <div className="flex items-center space-x-4">
                    <div className="bg-medallus-red/10 p-3 rounded-xl">
                      <DollarSign className="h-6 w-6 text-medallus-red" />
                    </div>
                    <div>
                      <div className="text-xl font-lato font-bold text-medallus-blue">8.0% Decrease</div>
                      <p className="text-medallus-text">in PEPY over the prior plan year</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="bg-medallus-red/10 p-3 rounded-xl">
                      <Target className="h-6 w-6 text-medallus-red" />
                    </div>
                    <div>
                      <div className="text-xl font-lato font-bold text-medallus-blue">5.4% Decrease</div>
                      <p className="text-medallus-text">in PEPY over the total analysis period</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="bg-medallus-red/10 p-3 rounded-xl">
                      <BarChart className="h-6 w-6 text-medallus-red" />
                    </div>
                    <div>
                      <div className="text-xl font-lato font-bold text-medallus-blue">28.4% Lower</div>
                      <p className="text-medallus-text">current year PEPY cost vs norm of $18,581</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <div className="bg-white p-8 rounded-xl shadow-lg">
                <h3 className="text-2xl font-lato font-bold text-medallus-blue mb-6">Program Performance</h3>
                <div className="space-y-6">
                  <div className="flex items-center space-x-4">
                    <div className="bg-medallus-red/10 p-3 rounded-xl">
                      <Users className="h-6 w-6 text-medallus-red" />
                    </div>
                    <div>
                      <div className="text-xl font-lato font-bold text-medallus-blue">2.45 Members</div>
                      <p className="text-medallus-text">per Contract (Norm: 2.05)</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="bg-medallus-red/10 p-3 rounded-xl">
                      <Stethoscope className="h-6 w-6 text-medallus-red" />
                    </div>
                    <div>
                      <div className="text-xl font-lato font-bold text-medallus-blue">$13,297</div>
                      <p className="text-medallus-text">Current PEPY Cost (2023/24)</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="bg-medallus-red/10 p-3 rounded-xl">
                      <Activity className="h-6 w-6 text-medallus-red" />
                    </div>
                    <div>
                      <div className="text-xl font-lato font-bold text-medallus-blue">Consistent Decline</div>
                      <p className="text-medallus-text">in Net Medical and Pharmacy Costs</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-12">
            <div className="bg-white p-8 rounded-xl shadow-lg">
              <img
                src="https://static.wixstatic.com/media/39a8a6_1529c83ed65147cca2c6d7e132bd61fc~mv2.png"
                alt="5 Year Cost Trend Analysis"
                className="w-full h-auto rounded-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* How We Did It Section */}
      {/* Rest of the sections remain exactly the same... */}
      <section className="py-24 bg-gradient-to-br from-gray-50 to-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-lato font-bold text-medallus-blue mb-4">Our Proven Approach</h2>
            <p className="text-lg text-medallus-text max-w-3xl mx-auto">
              Through years of experience serving school districts in North Dakota, we've developed a comprehensive healthcare delivery model that consistently delivers results.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-lato font-bold text-medallus-blue mb-8">Strategic Access</h3>
              <div className="space-y-8">
                <div className="flex items-start space-x-4">
                  <div className="bg-medallus-red/10 p-3 rounded-xl">
                    <MapPin className="h-6 w-6 text-medallus-red" />
                  </div>
                  <div>
                    <h4 className="text-lg font-lato font-bold text-medallus-blue mb-2">Multiple Convenient Locations</h4>
                    <p className="text-medallus-text">Three strategically placed clinics serving the Jamestown area and beyond, ensuring healthcare is always nearby for employees and their families.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-medallus-red/10 p-3 rounded-xl">
                    <Clock className="h-6 w-6 text-medallus-red" />
                  </div>
                  <div>
                    <h4 className="text-lg font-lato font-bold text-medallus-blue mb-2">Extended Hours & Availability</h4>
                    <p className="text-medallus-text">Open seven days a week with extended hours, accommodating both school schedules and after-hours care needs. Walk-ins welcome for both urgent and primary care.</p>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-2xl font-lato font-bold text-medallus-blue mb-8">Cost Control & Quality</h3>
              <div className="space-y-8">
                <div className="flex items-start space-x-4">
                  <div className="bg-medallus-red/10 p-3 rounded-xl">
                    <DollarSign className="h-6 w-6 text-medallus-red" />
                  </div>
                  <div>
                    <h4 className="text-lg font-lato font-bold text-medallus-blue mb-2">Transparent, Predictable Pricing</h4>
                    <p className="text-medallus-text">Visits as low as no cost to employees, with comprehensive care including lab work and x-rays at predictable costs, helping districts budget effectively.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-medallus-red/10 p-3 rounded-xl">
                    <Building2 className="h-6 w-6 text-medallus-red" />
                  </div>
                  <div>
                    <h4 className="text-lg font-lato font-bold text-medallus-blue mb-2">Independent Care Model</h4>
                    <p className="text-medallus-text">As an independent provider, we maintain full control over care decisions and referrals, helping to keep claims costs low and care quality high.</p>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-2xl font-lato font-bold text-medallus-blue mb-8">Quality Assurance</h3>
              <div className="space-y-8">
                <div className="flex items-start space-x-4">
                  <div className="bg-medallus-red/10 p-3 rounded-xl">
                    <Stethoscope className="h-6 w-6 text-medallus-red" />
                  </div>
                  <div>
                    <h4 className="text-lg font-lato font-bold text-medallus-blue mb-2">Standardized Clinical Excellence</h4>
                    <p className="text-medallus-text">All providers undergo rigorous training with Dr. Rachot Vacharothone, ensuring consistent, high-quality care across all locations. Regular quality reviews maintain standards.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-medallus-red/10 p-3 rounded-xl">
                    <FileText className="h-6 w-6 text-medallus-red" />
                  </div>
                  <div>
                    <h4 className="text-lg font-lato font-bold text-medallus-blue mb-2">Comprehensive Documentation</h4>
                    <p className="text-medallus-text">Detailed clinical documentation and care protocols ensure consistent treatment approaches and enable accurate tracking of health outcomes.</p>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-2xl font-lato font-bold text-medallus-blue mb-8">Proactive Management</h3>
              <div className="space-y-8">
                <div className="flex items-start space-x-4">
                  <div className="bg-medallus-red/10 p-3 rounded-xl">
                    <Activity className="h-6 w-6 text-medallus-red" />
                  </div>
                  <div>
                    <h4 className="text-lg font-lato font-bold text-medallus-blue mb-2">Active Care Management</h4>
                    <p className="text-medallus-text">Dedicated outreach team identifies and closes care gaps, manages chronic conditions, and ensures preventive care compliance through personalized outreach.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-medallus-red/10 p-3 rounded-xl">
                    <BarChart className="h-6 w-6 text-medallus-red" />
                  </div>
                  <div>
                    <h4 className="text-lg font-lato font-bold text-medallus-blue mb-2">Data-Driven Decisions</h4>
                    <p className="text-medallus-text">Regular analysis of utilization patterns, health outcomes, and cost metrics guides continuous program improvements and demonstrates ROI.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Impact Section */}
      <section className="py-24 bg-medallus-blue text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white/10 via-transparent to-transparent" />
        <div className="max-w-7xl mx-auto px-6 relative">
          <h2 className="text-3xl font-lato font-bold mb-12">The Impact for Employers</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white/10 backdrop-blur-sm p-6 rounded-xl border border-white/20">
              <BarChart className="h-8 w-8 text-medallus-red mb-4" />
              <p className="text-lg">Lower claims and insurance premiums</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm p-6 rounded-xl border border-white/20">
              <Heart className="h-8 w-8 text-medallus-red mb-4" />
              <p className="text-lg">Better chronic disease and preventive care management</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm p-6 rounded-xl border border-white/20">
              <Clock className="h-8 w-8 text-medallus-red mb-4" />
              <p className="text-lg">Reduced absenteeism and improved productivity</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm p-6 rounded-xl border border-white/20">
              <BarChart className="h-8 w-8 text-medallus-red mb-4" />
              <p className="text-lg">Predictable, transparent healthcare spend</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-white">
        <div className="max-w-3xl mx-auto px-6 text-center">
          <h2 className="text-3xl font-lato font-bold text-medallus-blue mb-6">
            Ready to Bring This Model to Your Organization?
          </h2>
          <p className="text-xl text-medallus-text mb-8">
            Whether you're a school district, municipality, or private employer—Medallus can implement a customized Near-site solution that works.
          </p>
          <Link
            to="/contact"
            className="inline-block px-8 py-4 bg-medallus-red text-white rounded-full font-lato font-bold hover:bg-opacity-90 transition-all duration-300 transform hover:-translate-y-1"
          >
            Schedule a Demo or Strategy Call
          </Link>
        </div>
      </section>
    </div>
  );
}