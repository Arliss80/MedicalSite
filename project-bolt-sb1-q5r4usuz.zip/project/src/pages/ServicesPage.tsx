import React from 'react';
import { Stethoscope, FlaskRound as Flask, Heart, Pill, Brain, Activity, Clock, Shield } from 'lucide-react';

export function ServicesPage() {
  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="relative py-32 bg-medallus-blue overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white/10 via-transparent to-transparent" />
        <div className="max-w-7xl mx-auto px-6 relative">
          <div className="max-w-3xl">
            <h1 className="text-5xl font-lato font-bold text-white leading-tight">
              Comprehensive Healthcare Services
            </h1>
            <p className="mt-6 text-xl text-white/80">
              From preventive care to urgent medical needs, our near-site clinics provide a full spectrum of healthcare services designed to keep your workforce healthy and productive.
            </p>
          </div>
        </div>
      </section>

      {/* Primary Care Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl font-lato font-bold text-medallus-blue mb-8">Primary Care Services</h2>
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="bg-medallus-red/10 p-3 rounded-xl">
                    <Stethoscope className="h-6 w-6 text-medallus-red" />
                  </div>
                  <div>
                    <h3 className="text-xl font-lato font-bold text-medallus-blue mb-2">Comprehensive Care</h3>
                    <p className="text-medallus-text">Our side clinic model provide both primary care and urgent care services to prevent illness and to treat illnesses that often need visits to emergency room or hospitals</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-medallus-red/10 p-3 rounded-xl">
                    <Heart className="h-6 w-6 text-medallus-red" />
                  </div>
                  <div>
                    <h3 className="text-xl font-lato font-bold text-medallus-blue mb-2">Chronic Disease Management</h3>
                    <p className="text-medallus-text">Ongoing care for conditions like diabetes, hypertension, and asthma</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-medallus-red/10 p-3 rounded-xl">
                    <Pill className="h-6 w-6 text-medallus-red" />
                  </div>
                  <div>
                    <h3 className="text-xl font-lato font-bold text-medallus-blue mb-2">Medication Management</h3>
                    <p className="text-medallus-text">Prescription services and medication monitoring</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative">
              <img
                src="https://static.wixstatic.com/media/39a8a6_95c62adb61724f24afa35af56d2504b4~mv2.png"
                alt="Primary care consultation"
                className="rounded-2xl shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Urgent Care Section */}
      <section className="py-24 bg-gradient-to-br from-gray-50 to-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="order-2 lg:order-1 relative">
              <img
                src="https://images.unsplash.com/photo-1581594693702-fbdc51b2763b"
                alt="Urgent care services"
                className="rounded-2xl shadow-2xl"
              />
            </div>
            <div className="order-1 lg:order-2">
              <h2 className="text-3xl font-lato font-bold text-medallus-blue mb-8">Urgent Care Services</h2>
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="bg-medallus-red/10 p-3 rounded-xl">
                    <Activity className="h-6 w-6 text-medallus-red" />
                  </div>
                  <div>
                    <h3 className="text-xl font-lato font-bold text-medallus-blue mb-2">Immediate Care</h3>
                    <p className="text-medallus-text">Quick treatment for non-emergency illnesses and injuries</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-medallus-red/10 p-3 rounded-xl">
                    <Clock className="h-6 w-6 text-medallus-red" />
                  </div>
                  <div>
                    <h3 className="text-xl font-lato font-bold text-medallus-blue mb-2">Extended Hours</h3>
                    <p className="text-medallus-text">Available seven days a week with convenient hours</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-medallus-red/10 p-3 rounded-xl">
                    <Shield className="h-6 w-6 text-medallus-red" />
                  </div>
                  <div>
                    <h3 className="text-xl font-lato font-bold text-medallus-blue mb-2">Cost-Effective Care</h3>
                    <p className="text-medallus-text">Avoid expensive emergency room visits for non-emergency conditions</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Diagnostic Services Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl font-lato font-bold text-medallus-blue mb-8">Diagnostic Services</h2>
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="bg-medallus-red/10 p-3 rounded-xl">
                    <Flask className="h-6 w-6 text-medallus-red" />
                  </div>
                  <div>
                    <h3 className="text-xl font-lato font-bold text-medallus-blue mb-2">On-Site Laboratory</h3>
                    <p className="text-medallus-text">Comprehensive testing capabilities with quick results</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-medallus-red/10 p-3 rounded-xl">
                    <Activity className="h-6 w-6 text-medallus-red" />
                  </div>
                  <div>
                    <h3 className="text-xl font-lato font-bold text-medallus-blue mb-2">X-Ray Services</h3>
                    <p className="text-medallus-text">Modern imaging equipment at every location</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-medallus-red/10 p-3 rounded-xl">
                    <Heart className="h-6 w-6 text-medallus-red" />
                  </div>
                  <div>
                    <h3 className="text-xl font-lato font-bold text-medallus-blue mb-2">Health Screenings</h3>
                    <p className="text-medallus-text">Preventive screenings and health assessments</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1576091160550-2173dba999ef"
                alt="Diagnostic services"
                className="rounded-2xl shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Wellness Programs Section */}
      <section className="py-24 bg-gradient-to-br from-gray-50 to-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="order-2 lg:order-1 relative">
              <img
                src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b"
                alt="Wellness programs"
                className="rounded-2xl shadow-2xl"
              />
            </div>
            <div className="order-1 lg:order-2">
              <h2 className="text-3xl font-lato font-bold text-medallus-blue mb-8">Wellness Programs</h2>
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="bg-medallus-red/10 p-3 rounded-xl">
                    <Brain className="h-6 w-6 text-medallus-red" />
                  </div>
                  <div>
                    <h3 className="text-xl font-lato font-bold text-medallus-blue mb-2">Health Education</h3>
                    <p className="text-medallus-text">Educational resources and workshops for better health management</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-medallus-red/10 p-3 rounded-xl">
                    <Heart className="h-6 w-6 text-medallus-red" />
                  </div>
                  <div>
                    <h3 className="text-xl font-lato font-bold text-medallus-blue mb-2">Preventive Care</h3>
                    <p className="text-medallus-text">Regular health assessments and preventive screenings</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-medallus-red/10 p-3 rounded-xl">
                    <Activity className="h-6 w-6 text-medallus-red" />
                  </div>
                  <div>
                    <h3 className="text-xl font-lato font-bold text-medallus-blue mb-2">Lifestyle Support</h3>
                    <p className="text-medallus-text">Guidance for healthy living and chronic condition management</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}