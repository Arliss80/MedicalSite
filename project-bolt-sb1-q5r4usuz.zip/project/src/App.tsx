import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { ScrollToTop } from './components/ScrollToTop';
import { HomePage } from './pages/HomePage';
import { AboutPage } from './pages/AboutPage';
import { BenefitsPage } from './pages/BenefitsPage';
import { ServicesPage } from './pages/ServicesPage';
import { LocationsPage } from './pages/LocationsPage';
import { ContactPage } from './pages/ContactPage';
import { GLP1Page } from './pages/GLP1Page';
import { GLP1DisclosurePage } from './pages/GLP1DisclosurePage';
import { ProvenConceptPage } from './pages/ProvenConceptPage';

function App() {
  return (
    <Router>
      <ScrollToTop />
      <div className="min-h-screen bg-white">
        <Navbar />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/benefits" element={<BenefitsPage />} />
          <Route path="/services" element={<ServicesPage />} />
          <Route path="/locations" element={<LocationsPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/glp1" element={<GLP1Page />} />
          <Route path="/glp1/disclosure" element={<GLP1DisclosurePage />} />
          <Route path="/proven-concept" element={<ProvenConceptPage />} />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

export default App;